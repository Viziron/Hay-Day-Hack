Password can be obtained from: http://tiny.cc/Password

The content is password protected to avert bots from stealing.

PASSOWRD: http://tiny.cc/Password